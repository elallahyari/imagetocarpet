"""
Carpet Design AI - سیستم هوشمند تبدیل تصویر به طرح صنعتی فرش
"""

__version__ = "1.0.0"
__author__ = "Carpet Design AI Team"